
function divisibleEntre7 (){

    for (let i = 1; i < 101; i++){

        if (i % 7 == 0){
            console.log(i);
        }

    }

}

export {divisibleEntre7} ;