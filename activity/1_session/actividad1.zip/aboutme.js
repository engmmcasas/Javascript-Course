//vconsole.log("about me.js")
function enunciado() {


        let miNombre = "Manuel Martinez Casas";
        let profesion = "Ingenieria en Inteligencia Artificial";
        let futuroPuesto = "Desarrollo Web";

        let output = `Hola, me llamo ${miNombre} y me dedico a ${profesion}. 
                Estoy cursando este Máster porque me gustaría trabajar en ${futuroPuesto}`;
        console.log(output);
        }
export { enunciado };
//console.log(output)
